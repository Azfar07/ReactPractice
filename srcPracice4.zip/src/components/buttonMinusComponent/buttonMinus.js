import React from 'react'

function ButtonMinus({setCount}) {
    
    // const minus=()=>{
    //     const a = 0;
    //     const res = 0;
    //     if (a > 0) {
    //         res = a-1;
    //     }
    //     return res;
    //   }
    
      return (
    <div>
      <button className = "button" onClick={()=> setCount(Count => Count - 1)}>-</button>
    </div>
  )
}

export default ButtonMinus;
