import React, { useState,useEffect } from 'react';
import ButtonPlus from '../buttonPlusComponent/buttonPlus';
import ButtonMinus from '../buttonMinusComponent/buttonMinus';
import Bcomponent from '../BComponent/BComponent';
import './Acomp.css';
function Acomponent() {
  const[Count,setCount]=useState(0);
  const[CountB,setCountB]=useState(0);
  const [countC, setCountC] = useState(0);
  
//   const handleChange=(CountB)=> {
//     setCountB(CountB);
//   }
//     const  handleCallback = (childData) =>{
//     this.setState({CountB: childData})
// }
const childToParent = (CountB) => {
    setCountB(CountB);
  }

 
    // console.log('====================================');
    // console.log({CountB});
    // console.log('====================================');
  return (

    <div>
        <div className="container">
        <div className = "custom-container">
                <h1>Component A</h1> 
        </div>
                <p>{Count}</p>
                <div >
                    <button  className = "button" onClick ={()=>{setCount( Count => Count +1)}}> + </button>
                    <button   className = "button" onClick={() => setCount(Count-1)}> - </button>
                </div>
                
            
            <div className = "custom-container">
                <h1>Component B</h1>
            </div>
                <p>{CountB}</p>
                <div>
                    <button className = "button" onClick={() => setCountB(CountB+1)}> + </button>
                    <button className = "button" onClick={() => setCountB(CountB-1)}> - </button>
                </div>

            <div className = "custom-container">
                <h1>Component C</h1>
            </div>
                <p>{countC}</p>
                <div>
                    <button className = "button" onClick={() => setCountC(countC+1)}> + </button>
                    <button className = "button" onClick={() => setCountC(countC-1)}> - </button>
                </div>
        
        </div>
                
            
        {/* <div className = "custom-container"> */}
        {/* childToParent={childToParent} */}
            {/* <ButtonPlus setCount = {setCount}  childToParent = {childToParent} ></ButtonPlus>
            <ButtonMinus setCount={setCount} ></ButtonMinus> */}
        
        {/* </div> */}
        <div>
            <Bcomponent 
            // childToParent={CountB}
             CountA = {Count}
             CountB={CountB}
             CountC={countC} 
             setContA= {setCount}
             setContB= {setCountB}
             setContC= {setCountC}
            // handleChange={handleChange}
            //changeCount = {CountB =>setCountB(CountB) }
             />
        </div>
    </div>
    
  )
}

export default Acomponent;
