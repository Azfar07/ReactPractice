import React from 'react'
import './button.css';
import Acomponent from '../AComponent/AComponent';
import Bcomponent from '../BComponent/BComponent';
function ButtonPlus({setCount,childToParent,countB}) {

const data = countB;
console.log(countB, 'hello');
//   let res = 0;
//   const plus=()=>{
//     const a = 1
//      res = a+1;
//     return res;
//   }
// const onTrigger = (event) => {
//   props.parentCallback({countB});
//   event.preventDefault();
  // {() => {
  //   greeting();
  //   waveHello();
  // }}
//}
  return (
    <div>
    {/* {data} */}
        <button className = "button" onClick ={()=>{setCount( Count => Count +1)}} >+</button>
    </div>
  )
}

export default ButtonPlus;