import React, { useState,useEffect } from 'react';
import ButtonPlus from '../buttonPlusComponent/buttonPlus';
import ButtonMinus from '../buttonMinusComponent/buttonMinus';
import './Ccomp.css';
function Ccomponent({CountA,CountB,CountC,setContA,setContB,setContC}) {
  const[Count,setCount]=useState(0);
     
  return (

    <div > 
    <div className='container' ></div>
    <div  className = "custom-container">
        <h1>Component A</h1>
    </div>
        <p>{CountA}</p>
    <div>
        <button className = "button" onClick={() => setContA(CountA+1)}> + </button>
        <button className = "button" onClick={() => setContA(CountA-1)}> - </button>
    </div>
    <div  className = "custom-container">
        <h1>Component B</h1>
    </div>
        <p>{CountB}</p>
    <div>
        <button className = "button" onClick={() => setContB(CountB+1)}> + </button>
        <button className = "button" onClick={() => setContB(CountB-1)}> - </button>
    </div>
    <div  className = "custom-container">
        <h1>Component C</h1>
    </div>
        <p>{CountC}</p>
    <div>
            <button className = "button" onClick={() => setContC(CountC+1)}> + </button>
            <button className = "button" onClick={() => setContC(CountC-1)}> - </button>
    </div>

      {/* <h1>Component C</h1>
      <p>{countA} of Comp A</p>
      <p>{countB} of Comp B</p>
      <p>{Count}  of Comp C</p>
      <div className = "custom-container">
            <ButtonPlus setCount = {setCount}></ButtonPlus>
            <ButtonMinus setCount={setCount}></ButtonMinus>
      </div>
       */}
    </div>
    
  )
}

export default Ccomponent;
