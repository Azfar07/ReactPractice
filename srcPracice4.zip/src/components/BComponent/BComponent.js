import React, { useState,useEffect } from 'react';
import ButtonPlus from '../buttonPlusComponent/buttonPlus';
import ButtonMinus from '../buttonMinusComponent/buttonMinus';
import Ccomponent from '../CComponent/CComponent';
import Acomponent from '../AComponent/AComponent';
import './Bcomp.css';
function Bcomponent({CountA,CountB,CountC,setContA,setContB,setContC}) {
    
    // const handleChange = (event) => {
    //     handleChange();
    // }
    // const onTrigger = (event) => {
    //     props.parentCallback({CountB});
    //     event.preventDefault();
    // }
   
  return (

    <div >
        <div  className = "container">
        <div  className = "custom-container">
            <h1>Component A</h1>
        </div>
            <p>{CountA}</p>
        <div>
            <button className = "button" onClick={() => setContA(CountA+1)}> + </button>
            <button className = "button" onClick={() => setContA(CountA-1)}> - </button>
        </div>
        <div  className = "custom-container">
            <h1>Component B</h1>
        </div>
            <p>{CountB}</p>
        <div>
            <button className = "button" onClick={() => setContB(CountB+1)}> + </button>
            <button className = "button" onClick={() => setContB(CountB-1)}> - </button>
        </div>
        <div  className = "custom-container">
            <h1>Component C</h1>
        </div>
            <p>{CountC}</p>
        <div>
                <button className = "button" onClick={() => setContC(CountC+1)}> + </button>
                <button className = "button" onClick={() => setContC(CountC-1)}> - </button>
        </div>
      
        </div>
      {/* <h1>Component B</h1>
      <p>{count} of Component A</p>
      <p>{Count} of Component B</p>
      <div className = "custom-container">
            <ButtonPlus setCount = {setCount} 
            countB = {Count} 
            setCountB= {setCount}></ButtonPlus>
            <ButtonMinus setCount={setCount} ></ButtonMinus> */}
      {/* </div>
      
      <div> */}
        <Ccomponent              
             CountA = {CountA}
             CountB={CountB}
             CountC={CountC} 
             setContA= {setContA}
             setContB= {setContB}
             setContC= {setContC} />
       {/* </div> */}
    </div>
    
  )
}

export default Bcomponent;
