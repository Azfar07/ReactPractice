import React from 'react'

function ShiftImage3({imageComp3,setImageComp3,shiftPictureFromComponent3ToParent}) {
  console.log(imageComp3,"imageComp3 at component")
  return (
    <div>
     <h1>Component 3</h1>
     {imageComp3?.map((pic,index)=>(
      <div key = {index}>
      <img style ={{width :'100px', height:'100px',flexDirection: 'row' }}  src={pic}  onClick = {shiftPictureFromComponent3ToParent} alt='error dog pic' ></img>
      </div>
    ))}
    </div>
  )
}

export default ShiftImage3