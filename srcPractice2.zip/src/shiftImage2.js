import React from 'react'

function ShiftImage2({imageComp2,setImageComp2,shiftPictureFromComponent2ToParent}) {
   
  console.log(imageComp2,"imageComp2 at component");
 
  return (
    <div>
    <h1>Component 2</h1>
    {imageComp2?.map((pic,index)=>(
      <div key = {index}>
      <img style ={{width :'100px', height:'100px',flexDirection: 'row' }}  src={pic}  onClick = {shiftPictureFromComponent2ToParent} alt='error dog pic' ></img>
      </div>
    ))}
    </div>
  )
}

export default ShiftImage2