import ShiftImage2 from './shiftImage2';
import ShiftImage3 from './shiftImage3';
import React, { useState, useEffect } from "react";
import "./App.css";
import axios from "axios";
function App() {
  const [image, setImage] = useState();
  const [imageComp2, setImageComp2] = useState([]);
  const [imageComp3, setImageComp3] = useState([]);
  const [noOfImage, setNoOfImage] = useState();
 
const handleSubmit =async()=>{
 let baseUrl =  'https://dog.ceo/api/breeds/image/random/'
 const response = await axios.get(baseUrl+noOfImage);
 setImage([...response.data.message]);
}

const shiftPictureFromParentToComponent = (index) =>{
  const imgShift = image?.filter((image,i)=> i === index )  
  const imgDelete = image?.filter((pic,i)=>i !==index )
   console.log('fghjfgj',imgDelete)
    setImage([...imgDelete]);
    setImageComp2([...imageComp2,...imgShift]);
   setImageComp3([...imageComp3,...imgShift]);
   
   console.log(imageComp3)
}

const shiftPictureFromComponent2ToParent = (index) =>{
  
  const imgShift = image?.filter((image,i)=> i === index )  
  const imgDelete = image?.filter((pic,i)=>i !==index )
   console.log('fghjfgj',imgDelete)
   setImageComp2([...imgDelete]);
    setImage([...image,...imgShift]);
  
}
const shiftPictureFromComponent3ToParent = (index) =>{
 
  const imgShift = image?.filter((image,i)=> i === index )  
  const imgDelete = image?.filter((pic,i)=>i !==index )
   console.log('fghjfgj',imgDelete)
   setImageComp3([...imgDelete]);
    setImage([...image,...imgShift]);
  
  
}
  return (
    <div >
      <div >
        <input type="text" onChange={(e)=>setNoOfImage(e.target.value)} />
        <button type="button" onClick={handleSubmit}>
          Show Pictures
        </button>
      </div>
      <div>
      <h1>Component 1</h1>
      {image?.map((pic,index) => (
        <div key={index}>
          <img style ={{width :'100px', height:'100px',flexDirection: 'row', display:'flex' }} onClick={()=>shiftPictureFromParentToComponent(index)} src={pic}></img>
        
        </div>
      ))} 
      </div>
      <ShiftImage2  imageComp2={imageComp2} setImageComp2 ={setImageComp2} shiftPictureFromComponent2ToParent={shiftPictureFromComponent2ToParent} />

      <ShiftImage3  imageComp3={imageComp3} setImageComp3 ={setImageComp3} shiftPictureFromComponent3ToParent={shiftPictureFromComponent3ToParent} />

    </div>
  );
}

export default App;
