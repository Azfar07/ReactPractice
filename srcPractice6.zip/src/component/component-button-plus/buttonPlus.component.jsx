import React from 'react'
import './button.css';

function buttonPlusComponent() {
  
  const plus=()=>{
    const a = 0
    const res = a+1;
    return res;
  }

  return (
    <div>
    <button class = "button" >Azfar</button>
    </div>
  )
}

export default buttonPlusComponent;