import React, { useState } from 'react';
function Acomponent() {
    
    const [plus, setPlus] = useState();
  return (
    <div>
      <h1>Component A</h1>
       <p>
       <buttonPlusComponent></buttonPlusComponent>
       
       </p>
      
    </div>
    
  )
}

export default Acomponent;
