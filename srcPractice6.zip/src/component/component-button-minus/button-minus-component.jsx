import React from 'react'

function buttonminuscomponent() {
    
    const minus=()=>{
        const a = 0;
        const res = 0;
        if (a > 0) {
            res = a--;
        }
        return res;
      }
    
      return (
    <div>
      <button class = "button" onClick={minus}>+</button>
    </div>
  )
}

export default buttonminuscomponent
