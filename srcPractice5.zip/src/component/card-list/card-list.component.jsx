import { Component } from "react";
import CardComponent from "../card/card.component";
import './card-list.css'

const CardList = ({ monsters }) =>(
        <div className="card-list">
            { 
                monsters?.map( (monster, index)=>
                {
                    return <CardComponent key={index} monster = {monster}/>;
                }
            )
        }
        </div>
);   

export default CardList;

// class CardListComponent extends Component {
//     render() {
//       //  console.log(this.props);
//       const { monsters } = this.props;
//         return (
//             <div className="card-list">
//             { monsters.map( (monster)=>{
//                         return <CardComponent monster = {monster}/>;
                         
//                     })}
//             </div>
//         );
//     }
// }
    

