import React, { Component } from 'react';
import CardList from '../card-list/card-list.component';
import './card.css'

const CardComponent = ({monster}) =>{
    const { id,username,name } = monster;
    return(
        <div className = 'card-container' key = {id}>
            <img alt = {`monster ${name}`} src = {`https://robohash.org/${id}?set=set2&size=180x180 `}/>
            <h2>{name}</h2>
            <p>{username}</p>
        </div>
    );
};
export default CardComponent;

// class CardComponent extends Component {
//     render() {
//         const { id,email,name } = this.props.monster;
//         return(
//             <div className = 'card-container' key = {id}>
//                 <img alt = {`monster ${name}`} src = {`https://robohash.org/${id}?set=set2&size=180x180 `}/>
//                 <h2>{name}</h2>
//                 <p>{email}</p>
//             </div>
//         )
//     }
// }




