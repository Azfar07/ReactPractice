import React, { Component } from 'react';
import './search-box.css';
const  SearchBoxComponent = ({onChangeHandler,placeholder,className}) =>{
    return(
            <input
                className= {`search-box ${className}`}
                type='search' 
                placeholder={placeholder} 
                onChange={onChangeHandler} 
                />
    );
};

// class SearchBoxComponent extends Component {
//     render() {
//         const { onChangeHandler } = this.props;
//         const { placeholder } = this.props;
//         const { className } = this.props;
//         return (
//             <div>
//                   <input
//                   className= {`search-box ${className}`}
//                    type='search' 
//                    placeholder={placeholder} 
//                    onChange={onChangeHandler} 
//                 />
//             </div>
//         );
//     }
// }

export default SearchBoxComponent;
