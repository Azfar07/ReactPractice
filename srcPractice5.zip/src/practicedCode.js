// constructor() {
//     super();
 
//     this.state = {
    
//      name: {firstname : 'Azfar', lastName: 'Arshad'}, 
//        compnay : 'ZTM'
//     };
//   }


// <header className="App-header">
// <img src={logo} className="App-logo" alt="logo" />
// <p>
//     Hi {this.state.name.firstName} {this.state.name.lastName},I work at {this.state.company}
// </p>
// <button onClick = { 
//   ()=>{
//         // this.setState(
//             // {
//             //     name: {firstname : 'ALI', lastName: 'AHMED'}, 
//             //     compnay : 'Telenor'
//             // });
//             this.setState(
//               ()=>{
//                 return {
//                   name: {firstname : 'ALI', lastName: 'AHMED'}, 
//                   compnay : 'Telenor'
//                 };
//             },
//             ()=>{
//               console.log(this.state);
//             } )
//         }} > Change
// </button>
// <a
//   className="App-link"
//   href="https://reactjs.org"
//   target="_blank"
//   rel="noopener noreferrer"
// >
//   Learn React
// </a>
// </header>

// import React, { Component } from 'react';
// import logo from './logo.svg';
// import './App.css';

// export default class componentName extends Component {
//   constructor() {
//     super()
  
//     this.state = {
//       monsters : [
//         {
//           name : 'Linda',
//           id : '1273tyvdy'
//         },
//         {
//           name : 'Jack',
//           id : '7364tgeyu'
//         },
//         {
//           name : 'John',
//           id : '3465gsdh'
//         },
//       ],
//     };
//   }
       
//     render() {
//     return (
//       <div className="App">
//       {
//         this.state.monsters.map((monster)=>{
//           return <div key ={monster.id}><h1>{monster.name}</h1></div>
//         })
//       }
//     </div>
//     );
//   }
// }



  //const [stringField,setStringField] = useState('');

 // const changeHandler = (event)=>{
  //   setSearchField(event.target.value);
  // }
   {/* <SearchBoxComponent 
   onChangeHandler = {changeHandler} 
   
   className = 'seatch Monster' /> */}


    //console.log({startingArray : this.state.monsters});
    // this.setState(()=>{
    //   return { searchField };
    // }
    // ()=>{
    //   console.log({endingArray : this.state.monsters});
    // }
    // )    
  

// {/* {
//  filteredMonster.map((monster)=>{
//    return <div key ={monster.id}><h1>{monster.name}</h1></div>
//  })
// } */}


//}

// export default class componentName extends Component {
//   constructor() {
//     super();
//     this.state = {
//       monsters : [],
//       searchField : ''
//     };
//     console.log('constructor');
//   }
  
  // componentDidMount(){
  //   console.log('componentDidMount');
  //   fetch('https://jsonplaceholder.typicode.com/users')
  //   .then((response)=>response.json())
  //   .then((data)=>this.setState(
  //     ()=>{
  //       return {monsters : data}
  //     },
       // ()=>{
       //   console.log(this.state);
       // }
  //   ));
  // }
  
  // onSearchChange = (event)=>{
  //   console.log({startingArray : this.state.monsters});
  //   const searchField = event.target.value.toLowerCase();
  //   this.setState(()=>{
  //     return { searchField };
  //   }
  //    ()=>{
  //      console.log({endingArray : this.state.monsters});
  //    }
  //   )}
       
    // render() {
    //   console.log('render');

    //   const {monsters, searchField} = this.state;
    //   const {onSearchChange} = this;

    //   const filteredMonster = this.state.monsters.filter((monster)=>{
    //     return monster.name.toLowerCase().includes(searchField);
    //   });

    // return (
      
    //   <div className="App">
    //      <h1 className = 'app-title'>Monster Rolodex</h1>
    //       <SearchBoxComponent 
    //       onChangeHandler = {onSearchChange} 
    //       placeholder = 'search'
    //       className = 'seatch Monster' />
    //       <CardList monsters = {filteredMonster}/>
    //   {/* {
    //     filteredMonster.map((monster)=>{
    //       return <div key ={monster.id}><h1>{monster.name}</h1></div>
    //     })
    //   } */}
      
    // </div>
    // );
//   }
// }

