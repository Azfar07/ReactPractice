import {useState, useEffect} from 'react';
//import React, { Component } from 'react';
import CardList from './component/card-list/card-list.component';
import SearchBoxComponent from './component/search-box/search-box.component';
import './App.css';
import CardComponent from './component/card-list/card-list.component';

const App = () =>{
  const [searchField,setSearchField] = useState('');
  const [monsters,setMonsters] = useState();
  const [filteredMonsters,setfilteredMonsters] = useState(monsters);
  

  useEffect(()=>{
    fetch('https://jsonplaceholder.typicode.com/users')
    .then((response)=>response.json())
    .then((data)=>setMonsters(data))
  },[]);

useEffect(() => {
  if(searchField){
  const NewFilteredMonster = monsters?.filter((monster)=>{
    return monster.name.toLowerCase().includes(searchField);
})
setfilteredMonsters(NewFilteredMonster);

  }
},[monsters,searchField]);

const onSearchChange = (event) =>{
  console.log('====================================');
  console.log(event.target.value);
  console.log('====================================');
  const searchFieldString = event.target.value.toLowerCase();
  setSearchField(searchFieldString);
}

 console.log(monsters,"monsters");
return(

<div className="App">
  <h1 className = 'app-title'>Monster Rolodex</h1>
   <SearchBoxComponent 
   onChangeHandler = {onSearchChange} 
   placeholder = 'search'
   className = 'search Monster' />
     <CardList monsters = {filteredMonsters || monsters}/>
</div>
);
}
export default App;

