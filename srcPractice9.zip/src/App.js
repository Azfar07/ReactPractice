import React, { useState } from 'react';
import Todo from './components/todoList/todo.js';

import './App.css';

function App() {
  return (
    <div>
      <Todo />       
    </div>
  );
}

export default App;
