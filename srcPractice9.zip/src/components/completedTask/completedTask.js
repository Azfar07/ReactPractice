import React, { useState } from 'react';

function CompletedTask({setTaskC,taskC,taskComplete}) {

  return (
    <div>
    <h1>Completed Task</h1>
    <div>
    <ul>

      {
        taskC?.map((task,index)=>(
                <li key = {index}>{task.task}</li>
        ))
      }
      </ul>

    </div>    
</div>
  );
}

export default CompletedTask;
