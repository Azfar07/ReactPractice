import Layout from "./Layout";
import React, { useState, useEffect } from "react";
import axios from "axios";
import Modal1 from "./Modal";
import AddComment from "./AddComment";
import Comments from "./Comments";
import ShowMore from "react-show-more-button/dist/module";
function AllPost({
  ShowUserPost,
  setEdit,
  handleInputEditChange,
  showPostData,
  setShowPostData,
  AllUserPosts,
  allPost,
  AllComments,
  edit,
  DeleteComments,
  DeletePost,
}) {
  const style = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: 400,
    bgcolor: "background.paper",
    border: "2px solid #000",
    boxShadow: 24,
    p: 4,
  };
  const [tempData, setTempData] = useState("");

  const handleOpenPost = () => setShowPostData(true);
  const handleClosePost = () => setShowPostData(false);
  const [tempPost, setTempPost] = useState();
  const getPost = async (id) => {
    try {
      const token = localStorage.getItem("tokenID");
      const userID = localStorage.getItem("user_id");
      const response = await axios.get(
        `https://taskforum.herokuapp.com/api/post/${id}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
    } catch (error) {
      console.log("error==>", error);
    }
  };

  const style1 = {
    marginLeft: "210px ",
    marginTop: "-48px",
  };
  useEffect(() => {
    AllUserPosts();
  }, []);
  const container = {
    display: "flex",
    justifyContent: "space-between",
    flexDirection: "row",
    flexWrap: "wrap",
  };

  return (
    <div>
      <div>
        <Modal1 
          ShowUserPost={ShowUserPost}
          showPostData={showPostData}
          handleClosePost={handleClosePost}
          style={style}
          edit={edit}
          setEdit={setEdit}
          tempData={tempData}
          setTempData={setTempData}
          handleInputEditChange={handleInputEditChange}
       
        />
        <Layout />
      </div>

      <div>
        <h1>All Posts</h1>
      </div>
      <div style={container}>
        {allPost?.map((data) => (
          <div key={data._id}>
            <div className="detailBox">
              <div className="titleBox">
                <label>{data.description}</label>
                <button
                  onClick={DeletePost}
                  type="button"
                  className="close"
                  aria-hidden="true"
                >
                  &times;
                </button>
              </div>
              <div
                className="commentBox"
                onClick={() => {
                  handleOpenPost();
                  setTempData(data._id);
                }}
              >
                <p className="taskDescription">{data.title}</p>{" "}
              </div>
              <ShowMore>
                <div className="actionBox">
                  <Comments
                    style1={style1}
                    DeleteComments={DeleteComments}
                    setTempData={setTempData}
                    dataId={data?._id}
                    handleOpenPost={handleOpenPost}
                  />
                  <AddComment AllComments={AllComments} dataId={data?._id} />
                </div>
              </ShowMore>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default AllPost;
