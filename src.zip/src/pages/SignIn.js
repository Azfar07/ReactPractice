import "./SignIn.css";
import axios from "axios";
import { Link, Outlet } from "react-router-dom";
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
function SignIn() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const SignInData = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "https://taskforum.herokuapp.com/api/auth/signin",
        {
          email,
          password: pass,
        }
      );
      localStorage.setItem("tokenID", response.data.token);
      localStorage.setItem("user_id", response.data.id);
      response !== null ? navigate("/Home") : navigate("SignIn");

      console.log(response);
    } catch (error) {
      console.log("error ==>", error);
    }
  };
  return (
    <div className="login-page">
      <div className="form">
        <form className="login-form" onSubmit={(e) => SignInData(e)}>
          <h1>Login</h1>
          <input
            type="email"
            placeholder="email"
            onChange={(e) => setEmail(e.target.value)}
          />
          <input
            type="password"
            placeholder="password"
            onChange={(e) => setPass(e.target.value)}
          />
          <button>login</button>
          <p className="message">
            Not registered?<a href="SignUp">Create an account</a>
          </p>
        </form>
      </div>
    </div>
  );
}

export default SignIn;
