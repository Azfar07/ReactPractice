import '../App.css';
import './Layout.css';
import axios from "axios";
import {Link,Outlet} from "react-router-dom";
import Home from "./Home";
import Signup from "./Signup";
import SignIn from "./SignIn";
import Post from "./Post";
import ProfileSetting from "./ProfileSetting";
function Layout({AllUserPosts}) {
  return (
    <>
        <nav className='nav'>
            <ul className='nav-links '>
                <li>
                  <Link to='/Home'>Home</Link>     
                </li>
                <li>
                  <Link onClick={AllUserPosts} to='/AllUserPost'>All Posts</Link>
                </li>
                <li>
                  <Link to='/ProfileSetting'>Profile Setting</Link>
                </li>
                <li>
                  <Link to='/CreatePost'>Create Post</Link>
                </li>  
                <li>
                  <Link to='/SignIn'>Log Out</Link>
                </li>
              </ul> 
                 
          </nav>
          <Outlet/>    
    </>
  )
}

export default Layout