import React, { useEffect } from "react";
import Layout from "./Layout";
import PostAndComment from "./PostAndComment";
function Home({
  ShowUserPost,
  handleInputEditChange,
  handleUpdate,
  showPostData,
  setShowPostData,
  edit,
  setEdit,
  showPost,
  userPost,
  UpdateComments,
  AddComments,
  AllComments,
}) {
  return (
    <div>
      <Layout />
      <PostAndComment
        AddComments={AddComments}
        AllComments={AllComments}
        UpdateComments={UpdateComments}
        ShowUserPost={ShowUserPost}
        handleInputEditChange={handleInputEditChange}
        handleUpdate={handleUpdate}
        showPostData={showPostData}
        setShowPostData={setShowPostData}
        edit={edit}
        setEdit={setEdit}
      />
    </div>
  );
}
export default Home;
