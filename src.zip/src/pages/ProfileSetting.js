import Layout from "./Layout";
import axios from "axios";
import React, { useState, useEffect } from "react";

function ProfileSetting() {
  const [name, setName] = useState("");
  const [data, setData] = useState();
  const updateUserData = async (e, id) => {
    e.preventDefault();
    const token = localStorage.getItem("tokenID");
    const matchedID = data.find((info) => info._id === id);
    try {
      if (matchedID !== "") {
        const response = await axios.put(
          `https://taskforum.herokuapp.com/api/users/${matchedID._id} `,
          {
            name,
          },
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
      }
    } catch (error) {
      console.log("error ==>", error);
    }
  };
  const getUserData = async () => {
    const userID = localStorage.getItem("user_id");
    const token = localStorage.getItem("tokenID");
    try {
      const response = await axios.get(
        `https://taskforum.herokuapp.com/api/users/${userID}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      setData([response.data.data]);
    } catch (error) {
      console.log("error ==>", error);
    }
  };
  useEffect(() => {
    getUserData();
    console.log("userData==>", data);
  }, []);
  return (
    <div>
      <Layout />
      <h2 style={{ textAlign: "center" }}> Update User</h2>
      {data?.map((info) => (
        <div key={info._id}>
          <div className="login-page">
            <div className="form">
              <form
                className="login-form"
                onSubmit={(e) => {
                  updateUserData(e, info._id);
                  getUserData();
                }}
              >
                <h1>Selected User: {info.name} </h1>
                <input
                  onChange={(e) => setName(e.target.value)}
                  type="text"
                  placeholder="name"
                />
                <button>Update</button>
              </form>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
export default ProfileSetting;
