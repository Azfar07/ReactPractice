import axios from "axios";
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
// import 'bootstrap/dist/css/bootstrap.css';
// import 'bootstrap/dist/css/bootstrap.min.css';
import "./Signup.css";
import { Link, Outlet } from "react-router-dom";
function Signup({ name, setName }) {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const postData = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "https://taskforum.herokuapp.com/api/auth/signup",
        {
          name,
          email,
          password: pass,
        }
      );
      response !== null ? navigate("/SignIn") : navigate("/");
      console.log(response);
    } catch (error) {
      console.log("error ==>", error);
    }
  };
  return (
    <div className="login-page">
      <div className="form">
        <form className="register-form" onSubmit={(e) => postData(e)}>
          <h1>Sign Up</h1>
          <input
            type="text"
            placeholder="name"
            onChange={(e) => setName(e.target.value)}
          />
          <input
            type="password"
            placeholder="password"
            onChange={(e) => setPass(e.target.value)}
          />
          <input
            type="email"
            placeholder="email address"
            onChange={(e) => setEmail(e.target.value)}
          />
          <button type="submit" value="Submit">
            Create
          </button>
          <p className="message">
            Already registered? <a href="SignIn">Sign In</a>
          </p>
        </form>
      </div>
    </div>
  );
}

export default Signup;
