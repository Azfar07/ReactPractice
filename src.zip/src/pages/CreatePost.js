import React from "react";
import Layout from "./Layout";
import axios from "axios";
function CreatePost({
  title,
  message,
  category,
  setTitle,
  setMessage,
  setCategory,
}) {
  const makePost = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem("tokenID");
    const userID = localStorage.getItem("user_id");
    try {
      const response = await axios.post(
        "https://taskforum.herokuapp.com/api/post/",
        {
          user: userID,
          title: title,
          category: category,
          description: message,
        },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      console.log("create post===>", response);
    } catch (error) {
      console.log("error ==>", error);
    }
  };
  return (
    <div>
      <Layout />
      <div className="login-page">
        <div className="form">
          <form
            className="login-form"
            onSubmit={(e) => {
              makePost(e);
            }}
          >
            <h1>Create Post</h1>
            <div>
              <label>Title</label>
              <input
                type="text"
                id="title"
                className="form-control"
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </div>
            <div>
              <label>Category</label>
              <input
                type="text"
                id="title"
                className="form-control"
                onChange={(e) => setCategory(e.target.value)}
                required
              />
            </div>
            <div>
              <label>Content</label>
              <textarea
                id="content"
                className="form-control"
                rows="4"
                onChange={(e) => setMessage(e.target.value)}
                required
              ></textarea>
            </div>
            <button style={{marginTop : "30px"}}>Update</button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default CreatePost;
