import React, {useState} from "react";
import axios from "axios";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import TextField from "@mui/material/TextField";
import { Alert } from "@mui/material";
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import { styled } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';

function Modal1({
  tempData,
  AllComments,
  setTempData,
  showPostData,
  handleClosePost,
  style,
  edit,
  setEdit,
  ShowPost,
  userPost,ShowUserPost
})

{
  const handleUpdate = async (id) => {
    const token = localStorage.getItem("tokenID");
    const updatedPost = userPost.find((post) => post._id === id);
  
    try {
      if (updatedPost !== "") {
        const response = await axios.put(
          `https://taskforum.herokuapp.com/api/post/${updatedPost._id}`,
          {
            title: edit,
          },
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
      }
    } catch (error) {
      console.log("error ==>", error);
    }
  };
  const UpdateComments = async (id) => {
    debugger;
  
    const userID = localStorage.getItem("user_id");
    const token = localStorage.getItem("tokenID");
    try {
      const response = await axios.put(
        `https://taskforum.herokuapp.com/api/comment/${id}`,
        {
          comment: edit,
        },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
    } catch (error) {
      console.log("error ==>", error);
    }
  };

  return (
    <div>
      {console.log("tempData==>", tempData)}
      <Modal
        open={showPostData}
        onClose={handleClosePost}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box  sx={style}>
          <Typography id="modal-modal-title" variant="h6" component="h2">
            Update Post
          </Typography>
          <TextField
          style={{marginTop:"20px"}}
            onChange={(e) => setEdit(e.target.value)}
            id="outlined-basic"
            label="Outlined"
            variant="outlined"
          />
          <Button
            onClick={() => {
              handleUpdate(tempData);
              ShowUserPost();
            }}
            onClose={handleClosePost}
            variant="outlined"
          >
            Update Post
          </Button>
          <Button
            style={{marginBlock:'20px', marginInline: "20px" }}
            onClick={() => {
              UpdateComments(tempData);
              AllComments();
            }}
            variant="outlined"
          >
            Update Comment
          </Button>
        </Box>
      </Modal>
    </div>
  );
}

export default Modal1;
