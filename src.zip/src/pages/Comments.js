import axios from "axios";
import React, { useState, useEffect } from "react";
import ShowMore from "react-show-more-button/dist/module";
import Modal1 from "./Modal";
function Comments({
  dataId,
  handleOpenPost,
  setTempData,
  style1,
  DeleteComments,
}) {
  const [allComment, setAllComment] = useState([]);
  const AllComments = async () => {
    try {
      const userID = localStorage.getItem("user_id");
      const token = localStorage.getItem("tokenID");
      const response = await axios.get(
        "https://taskforum.herokuapp.com/api/comment/",
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      const sortedComments = [...response.data.data].sort((a, b) =>
        a.created_at > b.created_at ? -1 : 1
      );
      console.log("strAscending==>", sortedComments);
      setAllComment(sortedComments);
    } catch (error) {
      console.log("error ==>", error);
    }
  };
  useEffect(() => {
    AllComments();
  }, []);
  return (
    <ShowMore>
      <div>
        {allComment?.map((comment) => (
          <div key={comment?._id}>
            {comment?.post?._id === dataId ? (
              <ol className="commentList" key={comment._id}>
                <li>
                  <div
                    className="commentText"
                    onClick={() => {
                      handleOpenPost();
                      setTempData(comment._id);
                    }}
                  >
                    <div>
                      <p> {comment?.comment} </p>
                      {comment?.user?._id !==
                      localStorage.getItem("user_id") ? (
                        console.log("error in button")
                      ) : (
                        <button
                          style={style1}
                          className="btn btn-default"
                          onClick={DeleteComments}
                        >
                          Delete
                        </button>
                      )}
                    </div>

                    <span className="date sub-text">{comment.created_at}</span>
                  </div>
                </li>
              </ol>
            ) : (
              ""
            )}
          </div>
        ))}
      </div>
        <Modal1 AllComments={AllComments} />
    </ShowMore>
  );
}

export default Comments;
