import React from 'react'

function Comment() {
  return (
    <div>Comment</div>
  )
}

export default Comment