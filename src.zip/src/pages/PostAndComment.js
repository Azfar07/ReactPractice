import "./PostAndComment.css";
import React, { useState, useEffect } from "react";
import Modal1 from "./Modal";
import ShowMore from "react-show-more-button/dist/module";
import AddComment from "./AddComment";
import Comments from "./Comments";
function PostAndComment({
  ShowUserPost,
  handleUpdate,
  showPostData,
  setShowPostData,
  edit,
  setEdit,
  userPost,
  UpdateComments,
  AllComments,
  DeleteComments,
  DeletePost,
}) {
  const [tempData, setTempData] = useState("");
  const handleOpenPost = () => setShowPostData(true);
  const handleClosePost = () => setShowPostData(false);

  const container = {
    display: "flex",
    justifyContent: "space-between",
    flexDirection: "row",
    flexWrap: "wrap",
  };
  const style1 = {
    marginLeft: "210px ",
    marginTop: "-48px",
  };

  const style = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: 400,
    bgcolor: "background.paper",
    border: "2px solid #000",
    boxShadow: 24,
    p: 4,
  };
  useEffect(()=>{
    ShowUserPost()
    console.log('ShowUserPost===>',ShowUserPost);
  },[])

  return (
    <div>
      <div>
        <h1>User Post</h1>
      </div>
      <div style={container}>
        {userPost?.map((data, i) => (
          <div>
            <div key={data.user}>
              <div className="detailBox">
                <div className="titleBox">
                  <label>Post</label>
                  <button
                    onClick={DeletePost}
                    type="button"
                    className="close"
                    aria-hidden="true"
                  >
                    &times;
                  </button>
                </div>
                <div
                  className="commentBox"
                  onClick={() => {
                    handleOpenPost();
                    setTempData(data._id);
                  }}
                >
                  <p className="taskDescription">{data.title}</p>{" "}
                </div>
                <div className="actionBox">
                  <ShowMore>
                    <Comments
                      style1={style1}
                      DeleteComments={DeleteComments}
                      setTempData={setTempData}
                      dataId={data?._id}
                      handleOpenPost={handleOpenPost}
                    />
                  </ShowMore>
                  <AddComment AllComments={AllComments} dataId={data?._id} />
                </div>
              </div>
              <Modal1
                UpdateComments={UpdateComments}
                ShowUserPost={ShowUserPost}
                showPostData={showPostData}
                handleClosePost={handleClosePost}
                style={style}
                setEdit={setEdit}
                tempData={tempData}          
                handleUpdate={handleUpdate}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default PostAndComment;
