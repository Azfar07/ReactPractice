import axios from "axios";
import React, { useState, useEffect } from "react";

function AddComment({ AllComments, dataId }) {
  const [comment, setComment] = useState("");

  const AddComments = async (e, post) => {
    //  debugger;
    e.preventDefault();
    try {
      const userID = localStorage.getItem("user_id");
      const token = localStorage.getItem("tokenID");
      const response = await axios.post(
        "https://taskforum.herokuapp.com/api/comment/",
        {
          user: userID,
          comment,
          post: post,
        },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
    } catch (error) {
      console.log("error ==>", error);
    }
  };
  const getCommment = async (id) => {
    try {
      const token = localStorage.getItem("tokenID");
      const userID = localStorage.getItem("user_id");
      const response = await axios.get(
        `https://taskforum.herokuapp.com/api/comment/${userID}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
    } catch (error) {
      console.log("error==>", error);
    }
  };
  return (
    <div>
      <form
        className="form-inline"
        role="form"
        onSubmit={(e) => {
          AddComments(e, dataId);
          AllComments();
        }}
      >
        <div className="form-group">
          <input
            className="form-control"
            type="text"
            onChange={(e) => setComment(e.target.value)}
            placeholder="Your comments"
          />
        </div>
        <div className="form-group">
          <button className="btn btn-default">Add</button>
        </div>
      </form>
    </div>
  );
}

export default AddComment;
