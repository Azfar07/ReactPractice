import axios from "axios";
import React, { useState, useEffect } from "react";
import { BrowserRouter, Routes, Route, useNavigate } from "react-router-dom";
import "./App.css";
import Comment from "./pages/Comment";
import SignIn from "./pages/SignIn";
import Signup from "./pages/Signup";
import CreatePost from "./pages/CreatePost";
import Home from "./pages/Home";
import Layout from "./pages/Layout";
import ProfileSetting from "./pages/ProfileSetting";
import PostAndComment from "./pages/PostAndComment";
import Post from "./pages/Post";

function App() {
  //States

  const navigate = useNavigate();
  const [message, setMessage] = useState("");
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [userPost, setUserPost] = useState();
  const [allPost, setAllPost] = useState();
  const [comment, setComment] = useState("");
  const [allComment, setAllComment] = useState();
  const [data, setData] = useState();
  const [edit, setEdit] = useState("");
  const [showComment, setShowComment] = useState(false);
  const [showPostData, setShowPostData] = useState(false);

  const AuthWrapper = () => {
    const token = localStorage.getItem("tokenID");
    token === null ? navigate("/SignIn") : console.log("error ==>");
  };

  //function for user
  const postData = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "https://taskforum.herokuapp.com/api/auth/signup",
        {
          name,
          email,
          password: pass,
        }
      );
      response !== null ? navigate("/SignIn") : navigate("/");
      console.log(response);
    } catch (error) {
      console.log("error ==>", error);
    }
  };

  const SignInData = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "https://taskforum.herokuapp.com/api/auth/signin",
        {
          email,
          password: pass,
        }
      );
      localStorage.setItem("tokenID", response.data.token);
      localStorage.setItem("user_id", response.data.id);
      response !== null ? navigate("/Home") : navigate("SignIn");

      console.log(response);
    } catch (error) {
      console.log("error ==>", error);
    }
  };

  const getUserData = async () => {
    const userID = localStorage.getItem("user_id");
    const token = localStorage.getItem("tokenID");
    try {
      const response = await axios.get(
        `https://taskforum.herokuapp.com/api/users/${userID}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      setData([response.data.data]);
    } catch (error) {
      console.log("error ==>", error);
    }
  };

  const updateUserData = async (e, id) => {
    e.preventDefault();
    const token = localStorage.getItem("tokenID");
    const matchedID = data.find((info) => info._id === id);
    try {
      if (matchedID !== "") {
        const response = await axios.put(
          `https://taskforum.herokuapp.com/api/users/${matchedID._id} `,
          {
            name,
          },
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
      }
    } catch (error) {
      console.log("error ==>", error);
    }
  };

  //functions for user Post
  const makePost = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem("tokenID");
    const userID = localStorage.getItem("user_id");
    try {
      const response = await axios.post(
        "https://taskforum.herokuapp.com/api/post/",
        {
          user: userID,
          title: title,
          category: category,
          description: message,
        },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      console.log("create post===>", response);
    } catch (error) {
      console.log("error ==>", error);
    }
  };
  const ShowPost = async () => {
   debugger
    try {
      const userID = localStorage.getItem("user_id");
      const token = localStorage.getItem("tokenID");
      const baseUrl = `https://taskforum.herokuapp.com/api/post/user/${userID}`;
      const response = await axios.get(baseUrl, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setUserPost(response.data.data);
      console.log("arr ===>", response.data.data);
    } catch (error) {
      console.log("error ==>", error);
    }
  };
  const AllUserPosts = async () => {
    const token = localStorage.getItem("tokenID");
    try {
      const baseUrl = "https://taskforum.herokuapp.com/api/post";
      const response = await axios.get(baseUrl, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setAllPost(response.data.data);
      console.log("All posts ===>", response.data.data);
    } catch (error) {
      console.log("error ==>", error);
    }
  };
  const handleInputEditChange = (e) => {
    setEdit(e.target.value);
    console.log("handleInputEditChange===>", edit);
  };
  const handleUpdate = async (id) => {
    const token = localStorage.getItem("tokenID");
    const updatedPost = userPost.find((post) => post._id === id);

    try {
      if (updatedPost !== "") {
        const response = await axios.put(
          `https://taskforum.herokuapp.com/api/post/${updatedPost._id}`,
          {
            title: edit,
          },
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
      }
    } catch (error) {
      console.log("error ==>", error);
    }
  };

  //function for user Comments

  const AddComments = async (e, post) => {
    //  debugger;
    e.preventDefault();
    try {
      const userID = localStorage.getItem("user_id");
      const token = localStorage.getItem("tokenID");
      const response = await axios.post(
        "https://taskforum.herokuapp.com/api/comment/",
        {
          user: userID,
          comment,
          post: post,
        },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
    } catch (error) {
      console.log("error ==>", error);
    }
  };
  const AllComments = async () => {
    try {
      const userID = localStorage.getItem("user_id");
      const token = localStorage.getItem("tokenID");
      const response = await axios.get(
        "https://taskforum.herokuapp.com/api/comment/",
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      setAllComment(response.data.data);
    } catch (error) {
      console.log("error ==>", error);
    }
  };

  const getUserComments = async () => {
    const userID = localStorage.getItem("user_id");
    const token = localStorage.getItem("tokenID");
    try {
      const response = await axios.get(
        `https://taskforum.herokuapp.com/api/comment/user/${userID}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
    } catch (error) {
      console.log("error ==>", error);
    }
  };
  const UpdateComments = async (id) => {
    debugger;

    const userID = localStorage.getItem("user_id");
    const token = localStorage.getItem("tokenID");
    try {
      const response = await axios.put(
        `https://taskforum.herokuapp.com/api/comment/${id}`,
        {
          comment: edit,
        },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
    } catch (error) {
      console.log("error ==>", error);
    }
  };
  const PostComments = async () => {
    const userID = localStorage.getItem("user_id");
    const token = localStorage.getItem("tokenID");
    const postId = 0;
    try {
      const response = await axios.get(
        `https://taskforum.herokuapp.com/api/comment/post/${postId}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
    } catch (error) {
      console.log("error ==>", error);
    }
  };
  // const DeleteComments = async()=>{}

  useEffect(() => {
    ShowPost();
    getUserData();
    AllUserPosts();
    AllComments();
    console.log("userData==>", data);
    console.log("userPost==>", userPost);
    console.log("comment data ==>", allComment);
  }, []);
  return (
    <>
    <button onClick={ShowPost}></button>
      <Routes>
        <Route
          exact
          path="/"
          element={
            <Signup
              name={name}
              setName={setName}
              setEmail={setEmail}
              setPass={setPass}
              postData={postData}
            />
          }
        />
        <Route
          path="/ProfileSetting"
          element={
            <ProfileSetting
              getUserData={getUserData}
              name={name}
              setName={setName}
              updateUserData={updateUserData}
              data={data}
            />
          }
        />

        <Route
          path="/SignIn"
          element={
            <SignIn
              email={email}
              setEmail={setEmail}
              pass={pass}
              setPass={setPass}
              SignInData={SignInData}
            />
          }
        />
        <Route
          path="/CreatePost"
          element={
            <CreatePost
              title={title}
              setTitle={setTitle}
              message={message}
              setMessage={setMessage}
              category={category}
              setCategory={setCategory}
              makePost={makePost}
            />
          }
        />
        <Route
          path="/Home"
          element={
            <Home
            AddComments={AddComments}
            AllComments={AllComments}
            setComment={setComment}
              allComment={allComment}
              UpdateComments={UpdateComments}
              ShowPost={ShowPost}
              handleInputEditChange={handleInputEditChange}
              handleUpdate={handleUpdate}
              showComment={showComment}
              setShowComment={setShowComment}
              showPostData={showPostData}
              setShowPostData={setShowPostData}
              edit={edit}
              SetEdit={setEdit}
              userPost={userPost}
              setUserPost={setUserPost}
            />
          }
        />
        <Route
          path="/AllUserPost"
          element={
            <Post
              edit={edit}
              setEdit={setEdit}
              ShowPost={ShowPost}
              handleInputEditChange={handleInputEditChange}
              getUserComments={getUserComments}
              UpdateComments={UpdateComments}
              PostComments={PostComments}
              handleUpdate={handleUpdate}
              showComment={showComment}
              setShowComment={setShowComment}
              showPostData={showPostData}
              setShowPostData={setShowPostData}
              AllComments={AllComments}
              AddComments={AddComments}
              comment={comment}
              setComment={setComment}
              allComment={allComment}
              setAllComment={setAllComment}
              AllUserPosts={AllUserPosts}
              allPost={allPost}
              setAllPost={setAllPost}
            />
          }
        ></Route>
      </Routes>
    </>
  );
}

export default App;
