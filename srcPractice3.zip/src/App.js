import './App.css';
import React, {useState} from "react";
import axios from "axios";
import Card from 'react-bootstrap/Card';
import ListGroup from 'react-bootstrap/ListGroup';
function App() {
  const[info,setInfo] = useState([]);

  const handleApi = async()=>{
    let baseUrl = 'https://fakestoreapi.com/products';
    const response = await axios.get(baseUrl);
    let arr = response.data;
    setInfo(arr);
    }
  
  return (
    <div >
    <button onClick= {handleApi}>Hit Api</button>
    {console.log('info',info)} 
    
    {info.map((data,i)=>(   
      <Card key={data.id} >
      <Card.Img variant="top" style ={{width :'100px', height:'100px'}} src={data.image} alt='error' />
      <Card.Body>
        <Card.Title>{data.title}</Card.Title>
        <Card.Text>Description :{data.description}</Card.Text>
      </Card.Body>
      <ListGroup className="list-group-flush">
        <ListGroup.Item>Category :{data.category}</ListGroup.Item>
        <ListGroup.Item>Rating:{data.rating.rate}</ListGroup.Item>
        <ListGroup.Item>Count :{data.rating.count}</ListGroup.Item>
      </ListGroup>
    </Card>
    ))} 

{/* 
      <Card key={data.id} style={{ width: '18rem', border:'solid black' }}>
      <Card.Img variant="top" src={data.images} />
      <Card.Body>
        <Card.Title>{data.title}</Card.Title>
        <Card.Subtitle className="mb-2 text-muted">Price: {data.price}</Card.Subtitle>
        <Card.Text>{data.description}</Card.Text>
        <Card.Text>{data.category}</Card.Text>
        <Card.Link href="#">Card Link</Card.Link>
        <Card.Link href="#">Another Link</Card.Link>
      </Card.Body>
    </Card> */}
   
     
      {/* <div className="card" style="width: 18rem;">
          <img src="..." className="card-img-top" alt="..." ></img>
          <div className="card-body">
            <h5 className="card-title">Card title</h5>
            <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
          </div>
          <ul className="list-group list-group-flush">
            <li className="list-group-item">An item</li>
            <li className="list-group-item">A second item</li>
            <li className="list-group-item">A third item</li>
          </ul>
          <div className="card-body">
            <a href="#" className="card-link">Card link</a>
            <a href="#" className="card-link">Another link</a>
          </div>
        </div> */}
    </div>
  );
}

export default App;
