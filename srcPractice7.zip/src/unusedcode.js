import React, { useState } from 'react';

const Todo = () => {
    const [todos,setTodos] = useState([{}]);
    const [value,setValue] = useState("")
    
    const getData = (val) => {
      
        setTodos(val.target.value);
       // console.log(val.target.value,"hhhhh")
        
      }
      const createTodoIteams = (e) => {
        let random = Math.floor(Math.random() * 100)
        const newTodos = [...todos, {id : random, task : value}]
        setTodos(newTodos);
      }
      
      const handleAdd = (val)=>{
        val.preventDefault();

        if(value === ""){
            return console.log("Please add something to-do");
        }
        createTodoIteams(val);
        setValue("")
        
        // setTodos([ ...todos,{'id' : random , 'work':  inputValue}])
        // array.push({todos});
      }
    //   console.log(array,'hgshsh')

    return (
        <div>
            <input onChange = {(e) => setValue(e.target.value)}></input>
            <button type="button"  onClick = {handleAdd}>Add todo</button>
            <ul>
                {/* <li>{todos?.work}</li> */}
                
            </ul>
        </div>
    );
}
  // const handleAdd1 = (handleAdd)=>{
    //     let b = a.push(handleAdd);
    //     console.log(b.value);
    // }
     // let random = Math.random(); 
        // Object.assign(todos, {id : random});
   // setTodos({task : val.target.value,id:Math.random()});
      
       // console.log(val.target.value,"hhhhh")
        


export default Todo;
