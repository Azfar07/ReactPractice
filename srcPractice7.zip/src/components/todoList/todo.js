import React, { useState } from 'react';
import PendingTask from '../pendingTask/pendingTask.js';
import CompletedTask from '../completedTask/completedTask.js';
// import UpdateComponent from '../updateComponent/UpdateComponent.js';


import './todo.css';
const Todo = () => {
    let [todos,setTodos] = useState([]);
    let [updateTodos,setUpdateTodos] = useState();
    let [taskC,setTaskC] = useState([]);
    let [taskP,setTaskP] = useState([]);

    let handleUpdate = (id,update) => {
        const updatetask = todos.find((todo)=>{ return todo.id == id; });
           if(updatetask !== ''){
                const task = {task : update,id:Math.random()};

                setTodos([...todos,task])
            }
            setUpdateTodos(updatetask) 
    }
    console.log(updateTodos,"kjsdchsdjkc") 
    let current_value_input='';

    const getData = (val) => 
        {
           current_value_input=val.target.value;
          
        }
        
        const setData = (value,id ) => 
        {
            if(todos.find((todo)=>{ return todo.id == id; })){
                 current_value_input = value.target.value;
            }
        }
    const handleAdd = ()=>
        {
            if(current_value_input !== '')
            {
                const task = {task : current_value_input,id:Math.random()};     
                setTodos([...todos,task]);
               
            }
            current_value_input='';
            console.log(todos); 
        }
      const handleUpdateAdd = (id,updatedTodos)=>{
        const updatedTask = todos.map((todo)=>{
            if( todo.id === id){
                const updatedTask = {task : updatedTodos,id:Math.random()};     
                setTodos([...todos,updatedTask]);
            }
            console.log(todos)
        });    

      }
      const handleInputEditChange = (e)=>{
        setUpdateTodos({...updateTodos, task :e.target.value})
        console.log(updateTodos)
      }
    const deleteTodo = (id) =>
        {
            const todoDelete = todos.filter((todo)=>(todo.id !== id));
            setTodos(todoDelete);
        }

    const taskPending = (id) => 
        {
        const pending = todos.filter
        (
                (todo) =>( todo.id === id)
            )
        const todoTaskDelete = todos.filter
        (
                (todo) =>( todo.id !== id)
            )
        setTodos(todoTaskDelete);
        setTaskP([...taskP,...pending]);
        }
 
       
    const taskComplete = (id,todoIndex) => 
        {
            const pending = todos.filter
                (
                    (todo) =>( todo.id === id)
                );
            const todoTaskDelete = todos.filter
                (
                    (todo) =>( todo.id !== id)
                )
            setTodos(todoTaskDelete);
            setTaskC([...taskC,...pending]);
        }
        const onChange = (event) => {
            current_value_input=event.target.value; //update your value here
          }
      
    return (
        <div>
            <h1>Todo List</h1>
                    <input  onChange = {(e)=>getData(e)}></input> 
                                    <input
                                        type="text"
                                        id="message"
                                        name="message"
                                       onChange ={handleInputEditChange}
                                        value={updateTodos?.task}
                                    />
                    <button type="button"  onClick = {handleAdd}>Add todo</button>
                    <button type="button"  onClick = {handleUpdateAdd}>Update todo</button>
                    
                
     
                <table className="customers" >
                
                        <thead>
                        <tr>
                            <th>Work</th>
                            <th>Pending</th>
                            <th>Compeletd</th>
                            <th>Update</th>
                            <th>Delete</th>
                        </tr>

                        </thead>
                        {
                            todos.map((todo,index) => (
                                <tbody key={index} >
                                    <tr>
                                        <td>{todo.task}</td>
                                        
                                        <td>
                                            <button type = "button" onClick ={()=>{taskPending(todo.id)}}>Pending</button>
                                        </td>
                                        <td>
                                            <button type = "button" onClick ={()=>{taskComplete(todo.id)}}>Completed</button>
                                        </td>
                                        <td>
                                            <button type = "button" onClick ={() => handleUpdate(todo.id)}>Update</button>
                                        </td>
                                        <td>
                                            <button type = "button" onClick ={()=>{deleteTodo(todo.id)}} >Delete</button>
                                        </td>
                                    </tr>
                                </tbody>           
                    ))}
                    </table>
                            
            <PendingTask taskP= {taskP} setTaskP = {setTaskP} taskPending = {taskPending}/>
            <CompletedTask taskC= {taskC} setTaskC = {setTaskC} taskComplete = {taskComplete}/>
            {/* <UpdateComponent setData= {setData} show={show} setShow={setShow} handleClose={handleClose} handleOpen= {handleOpen} todos= {todos} setTodos = {setTodos} /> */}
        </div>
    );
}

export default Todo;
// onClick ={()=>{setTask1(value.task)}}
//    const todoTaskDelete =todos.filter(( todo , index) => todoIndex !== index)
//    const todoTaskDelete =todos.filter(( todo , index) => todoIndex !== index)