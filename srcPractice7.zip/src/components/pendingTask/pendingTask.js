import React, { useState } from 'react';


function PendingTask({setTaskP,taskP,taskPending}) {
    
  return (
    <div>
        <h1>Pending Task</h1>
        <div>
        <ul>

          {
            taskP?.map((task,index)=>(
                    <li key = {index}>{task.task}</li>
            ))
          }
          </ul>

        </div>    
    </div>
  );
}

export default PendingTask;
