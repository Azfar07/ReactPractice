import logo from './logo.svg';
import React, { useState } from 'react';
import './App.css';
// import TableComponent from './components/tableComponent/tableComponent';
function App() {
let obj = {
  name : "Azfar"
}
const [oldName,setName] = useState(obj)
const [newName,setNewName] = useState()

const getData = (val)=>{
  setNewName(val.target.value);
  console.log(val.target.value,"hhhhh")
  
} 
const handleUpdate = () => {
  setName({name : newName});
}
  // let updateValue ={name : val}
  // //console.log(updateValue,'fjnfjh')
  // setName(oldName =>({
  //   ...oldName,
  //   name : updateValue
  // }));
  // console.log(oldName,'hello')

// const handleAdd = (newName) => {
//   // newName = Object.assign({}, obj);
//   // newName[obj.name] = newName;
//   // setName(newName);
//   // setName({...newName, [newName.name]: newName});
//   console.log(setName({...newName, [newName.name]: newName.toString()}))
// }

  return (
    <div >
      <header >
              
          <p>{oldName.name}</p>

        <input onChange = {(e)=>getData(e)}></input>
        <button type="button" onClick ={handleUpdate} >Change Name</button>
        
      </header>
    </div>
  );
}

export default App;
