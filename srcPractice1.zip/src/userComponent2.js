import React from 'react'

function UserComponent2({img,setImg,img3,setImg3,shiftImg}) {
  return (
    <div>
        <h1>Other Component</h1>
        <img src = {img3?.message}></img>
    </div>
  )
}

export default UserComponent2