// useEffect(()=>{
//  fetch(`https://dog.ceo/api/breeds/image/random`)
//  .then(response =>response.json())
//  .then(data => {
//   setImg({image : data.message});
//  }).catch(error => cosnole.log('error),error)
//   // fetchImg();
// },[]);

// const fetchImg = async() =>{
//   const response = await fetch(`https://dog.ceo/api/breeds/image/random`);
//   const imgData = await response.json();
//   setImg(imgData);
// };