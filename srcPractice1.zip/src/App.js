import UserComponent2 from './userComponent2';
import React,{useState,useEffect} from 'react';
import './App.css'; 
function App() {
  const [img,setImg] = useState();
  const [img2,setImg2] = useState();
  const [img3,setImg3] = useState();

useEffect(()=>{
 fetch(`https://dog.ceo/api/breeds/image/random`)
 .then(response =>response.json())
 .then(data => {
  console.log('djbfjd',data?.message)
  setImg(data)
 })
  // fetchImg();
},[])

const shiftImg = () =>{
  setImg2(img);
  setImg(img2)
}
const shiftImg2 = () =>{
  setImg(img3)
  setImg3(img);
}  
// const fetchImg = async() =>{
//   const response = await fetch(`https://dog.ceo/api/breeds/image/random`);
//   const imgData = await response.json();
//   setImg(imgData);
// };



  return (
    <div className="App">
      {console.log('image==>',img)}
      <div>
          <img src={img?.message}></img>
      </div>
      <div className = "solid">
      <h2>second div</h2>
        <img src={img2?.message}></img>
      </div>
      <button onClick = {shiftImg}> Shift Image</button>
      <button onClick = {shiftImg2}> Shift Image to next component</button>
      <div className = "solid">
        <UserComponent2 img= {img} setImg={setImg}  img3 = {img3} setImg3={setImg3} shiftImg={shiftImg}  />
      </div>
    </div>
  );
}

export default App;
